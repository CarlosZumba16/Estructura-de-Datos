// 1. IMPORTAMOS EL ARBOL DESDE EL OTRO ARCHIVO
module.exports = MotorIndexacionBST;

class Main {
    static ejecutar() {
        console.log("==================================================");
        console.log("  INICIANDO MOTOR DE INDEXACIÓN Y PRUEBAS BST");
        console.log("==================================================\n");

        const motor = new MotorIndexacionBST();
        const Total_Keywords = 100000;
        let datosSecuenciales = [];

        console.log(`[1/4] Generando ${Total_Keywords.toLocaleString()} palabras clave...`);
        for (let i = 1; i <= Total_Keywords; i++) {
            datosSecuenciales.push("go_" + i.toString().padStart(5, '0'));
        }
        
        const palabraABuscar = datosSecuenciales[Total_Keywords - 1]; 

        console.log("[2/4] Aleatorizando datos para evitar degradación del BST...");
        const datosAleatorios = [...datosSecuenciales].sort(() => Math.random() - 0.5);

        console.log("[3/4] Indexando elementos en el árbol binario...");
        console.time("Tiempo de Indexación");
        datosAleatorios.forEach((keyword, index) => {
            motor.indexar(keyword, `https://cache.motor.com/search?q=${keyword}`);
            if (index % 10000 === 0) {
                motor.indexar(keyword, `https://cache.motor.com/search?q=${keyword}`);
            }
        });
        console.timeEnd("Tiempo de Indexación");

        console.log(`\n[4/4] Buscando la palabra clave objetivo: "${palabraABuscar}"...`);
        console.time("Tiempo de Búsqueda");
        const nodoEncontrado = motor.buscar(palabraABuscar);
        console.timeEnd("Tiempo de Búsqueda");

        console.log("\n==================================================");
        console.log("               RESULTADOS DE LA PRUEBA            ");
        console.log("==================================================");
        if (nodoEncontrado) {
            console.log(`✅ ¡Elemento Encontrado exitosamente!`);
            console.log(`   • Keyword:  ${nodoEncontrado.keyword}`);
            console.log(`   • URL:      ${nodoEncontrado.urlCache}`);
            console.log(`   • Visitas:  ${nodoEncontrado.visitas}`);
        } else {
            console.log("❌ El elemento no pudo ser hallado en el BST.");
        }

        console.log("\n📊 Muestra del Historial Exportado (Primeros 5 elementos A-Z):");
        const historialCompleto = motor.exportarHistorial();
        console.table(historialCompleto.slice(0, 5));
        console.log(`... y ${historialCompleto.length - 5} elementos más.`);
        console.log("==================================================");
    }
}

// EJECUTAR EL PROCESO
Main.ejecutar();
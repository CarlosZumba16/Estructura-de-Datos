// Estructura del Nodo del Índice
class NodoBusqueda {
    constructor(keyword, urlCache) {
        this.keyword = keyword;        
        this.urlCache = urlCache;      
        this.visitas = 1;              
        this.izquierdo = null;
        this.derecho = null;
    }
}

// Implementación del TDA Árbol Binario de Búsqueda
class MotorIndexacionBST {
    constructor() {
        this.raiz = null;
    }

    // Indexar nueva consulta en el historial
    indexar(keyword, urlCache) {
        const nuevoNodo = new NodoBusqueda(keyword, urlCache);
        if (this.raiz === null) {
            this.raiz = nuevoNodo;
        } else {
            this._insertarNodo(this.raiz, nuevoNodo);
        }
    }

    _insertarNodo(nodoActual, nuevoNodo) {
        const comparacion = nuevoNodo.keyword.localeCompare(nodoActual.keyword);

        if (comparacion === 0) {
            nodoActual.visitas++;
        } else if (comparacion < 0) {
            if (nodoActual.izquierdo === null) {
                nodoActual.izquierdo = nuevoNodo;
            } else {
                this._insertarNodo(nodoActual.izquierdo, nuevoNodo);
            }
        } else {
            if (nodoActual.derecho === null) {
                nodoActual.derecho = nuevoNodo;
            } else {
                this._insertarNodo(nodoActual.derecho, nuevoNodo);
            }
        }
    }

    // =========================================================================
    // NUEVO MÉTODO BUSCAR (Modificado para la Auditoría Eco-Friendly)
    // =========================================================================
    buscar(keyword, nodoActual = this.raiz, contador = { ciclos: 0 }) {
        if (nodoActual === null) {
            return { nodo: null, ciclos: contador.ciclos };
        }

        // Cada comparación cuenta como un ciclo de CPU (salto de nodo)
        contador.ciclos++;
        const comparacion = keyword.localeCompare(nodoActual.keyword);

        if (comparacion === 0) {
            return { nodo: nodoActual, ciclos: contador.ciclos }; 
        } else if (comparacion < 0) {
            return { nodo: this.buscar(keyword, nodoActual.izquierdo, contador).nodo, ciclos: contador.ciclos }; 
        } else {
            return { nodo: this.buscar(keyword, nodoActual.derecho, contador).nodo, ciclos: contador.ciclos }; 
        }
    }

    // Recorrido Inorden: Exportar el historial ordenado alfabéticamente (A-Z)
    exportarHistorial(nodo = this.raiz, resultado = []) {
        if (nodo !== null) {
            this.exportarHistorial(nodo.izquierdo, resultado);
            
            resultado.push({
                keyword: nodo.keyword,
                urlCache: nodo.urlCache,
                visitas: nodo.visitas
            });
            
            this.exportarHistorial(nodo.derecho, resultado);
        }
        return resultado;
    }
}

module.exports = MotorIndexacionBST;
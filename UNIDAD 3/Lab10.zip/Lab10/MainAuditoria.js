// LÍNEA 1: IMPORTAMOS (Traemos el árbol para usarlo aquí)
const MotorIndexacionBST = require('./MotorIndexacionBST');

function barajarFisherYates(array) {
    let copia = [...array];
    for (let i = copia.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copia[i], copia[j]] = [copia[j], copia[i]];
    }
    return copia;
}

class MainAuditoria {
    static ejecutar() {
        console.log("=========================================================");
        console.log("  TAREA 3: AUDITORÍA 'ECO-FRIENDLY' Y DEGRADACIÓN TÉRMICA");
        console.log("=========================================================\n");

        const TOTAL_ELEMENTOS = 20000;
        let palabrasOrdenadas = [];

        for (let i = 1; i <= TOTAL_ELEMENTOS; i++) {
            palabrasOrdenadas.push("kw_" + i.toString().padStart(5, '0'));
        }
        const palabraObjetivo = palabrasOrdenadas[TOTAL_ELEMENTOS - 1];

        // 1. Árbol Degenerado
        console.log("[Escenario 1] Creando árbol degenerado (Alta Huella de Carbono)...");
        const motorDegenerado = new MotorIndexacionBST();
        palabrasOrdenadas.forEach(kw => motorDegenerado.indexar(kw, `https://cache.io/${kw}`));

        const resultadoPeor = motorDegenerado.buscar(palabraObjetivo);
        console.log(` > Búsqueda en árbol degenerado: ${resultadoPeor.ciclos.toLocaleString()} ciclos de CPU.`);

        // 2. Árbol Sostenible
        console.log("\n[Escenario 2] Creando árbol sostenible mediante Fisher-Yates...");
        const motorSostenible = new MotorIndexacionBST();
        const palabrasBarajadas = barajarFisherYates(palabrasOrdenadas);
        palabrasBarajadas.forEach(kw => motorSostenible.indexar(kw, `https://cache.io/${kw}`));

        const resultadoMejor = motorSostenible.buscar(palabraObjetivo);
        console.log(` > Búsqueda en árbol pseudo-balanceado: ${resultadoMejor.ciclos.toLocaleString()} ciclos de CPU.`);

        // 3. Eficiencia
        const ciclosAhorrados = resultadoPeor.ciclos - resultadoMejor.ciclos;
        const porcentajeAhorro = (ciclosAhorrados / resultadoPeor.ciclos) * 100;

        console.log("\n=========================================================");
        console.log("                 INFORME DE EFICIENCIA                   ");
        console.log("=========================================================");
        console.log(`• Ciclos Desperdiciados (Peor):  ${resultadoPeor.ciclos}`);
        console.log(`• Ciclos Optimizados (Mejor):    ${resultadoMejor.ciclos}`);
        console.log(`• Reducción de operaciones:      ${ciclosAhorrados.toLocaleString()} saltos`);
        console.log(`• Porcentaje de Eficiencia:      ${porcentajeAhorro.toFixed(4)}% de ahorro energético.`);
        console.log("=========================================================");
    }
}

MainAuditoria.ejecutar();